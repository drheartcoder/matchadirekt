<!-- </div> -->
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="js/mobile-menu.js"></script>
<script src="js/hammer.min.js"></script>
<script src="js/tindercards.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/codemirror.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/mode/xml/xml.min.js"></script>
<script type="text/javascript" src="js/editor/froala_editor.min.js"></script>
<script type="text/javascript" src="js/editor/align.min.js"></script>
<script type="text/javascript" src="js/editor/code_beautifier.min.js"></script>
<script type="text/javascript" src="js/editor/code_view.min.js"></script>
<script type="text/javascript" src="js/editor/colors.min.js"></script>
<script type="text/javascript" src="js/editor/draggable.min.js"></script>
<script type="text/javascript" src="js/editor/emoticons.min.js"></script>
<script type="text/javascript" src="js/editor/font_size.min.js"></script>
<script type="text/javascript" src="js/editor/font_family.min.js"></script>
<script type="text/javascript" src="js/editor/image.min.js"></script>
<script type="text/javascript" src="js/editor/file.min.js"></script>
<script type="text/javascript" src="js/editor/image_manager.min.js"></script>
<script type="text/javascript" src="js/editor/line_breaker.min.js"></script>
<script type="text/javascript" src="js/editor/link.min.js"></script>
<script type="text/javascript" src="js/editor/lists.min.js"></script>
<script type="text/javascript" src="js/editor/paragraph_format.min.js"></script>
<script type="text/javascript" src="js/editor/paragraph_style.min.js"></script>
<script type="text/javascript" src="js/editor/video.min.js"></script>
<script type="text/javascript" src="js/editor/table.min.js"></script>
<script type="text/javascript" src="js/editor/url.min.js"></script>
<script type="text/javascript" src="js/editor/entities.min.js"></script>
<script type="text/javascript" src="js/editor/char_counter.min.js"></script>
<script type="text/javascript" src="js/editor/inline_style.min.js"></script>
<script type="text/javascript" src="js/editor/save.min.js"></script>
<script type="text/javascript" src="js/editor/fullscreen.min.js"></script>
<script type="text/javascript" src="js/editor/quote.min.js"></script>
<script type="text/javascript" src="js/editor/quick_insert.min.js"></script>
<script src='js/moment.min.js'></script>
<script src='js/fullcalendar.min.js'></script>
<script src='js/jquery-ui.min.js'></script>
<script src="js/custom.js"></script>
</body>

</html>