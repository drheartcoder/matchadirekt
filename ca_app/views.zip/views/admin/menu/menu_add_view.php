<div class="box-body">
  <div class="tab-content">
    <div class="form-group">
        <label  for="exampleInputPassword1">Menu Name</label>
        <input type="text" class="form-control"  id="menuName" name="menuName" value="" placeholder="Menu Name">
        <input type="hidden" id="method" name="method" value="add">
        <input type="hidden" id="pid" name="pid" value="">
    </div>
  </div>
</div>
 
 
