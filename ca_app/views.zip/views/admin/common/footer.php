<!--Footer Start-->
</div>
<!-- ./wrapper -->
<?php if($this->uri->segment(2)!='skills'):?>
<script src="<?php echo base_url('public/js/jquery-3.2.1.min.js'); ?>"></script>
<script src="<?php echo base_url('public/js/jquery-ui.js'); ?>"></script>
<script src="<?php echo base_url('public/js/admin/bootstrap.min.js');?>" type="text/javascript"></script>
<script src="<?php echo base_url('public/js/admin/admin_functions.js');?>" type="text/javascript"></script>
<script src="<?php echo base_url('public/js/validation.js');?>" type="text/javascript"></script>
<!--<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>-->
<?php endif;?>
</body>
</html>
<!--Footer End-->