<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="<?php echo base_url('public/js/jquery-1.11.0.js');?>"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo base_url('public/js/bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('public/js/bootbox.min.js');?>"></script>
<script src="<?php echo base_url('public/js/functions.js');?>" type="text/javascript"></script>
<script src="<?php echo base_url('public/js/validation.js');?>" type="text/javascript"></script>
<script src="<?php echo base_url('public/slider/owl.carousel.min.js');?>" type="text/javascript"></script> 
<script src="<?php echo base_url('public/js/custom.js');?>" type="text/javascript"></script>