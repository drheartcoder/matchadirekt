<!-- <div class="clear">&nbsp;</div> -->
<div class="text-center">
<?php //echo $ads_row->bottom;?>
</div>