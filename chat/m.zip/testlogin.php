<script type="text/javascript">
    parent.postMessage({
    type:'preview.compiled',
    },"*");
</script>
