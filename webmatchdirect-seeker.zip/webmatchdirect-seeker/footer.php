<!-- </div> -->
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="js/mobile-menu.js"></script>
<script src="js/hammer.min.js"></script>
<script src="js/tindercards.js"></script>
<script src='js/moment.min.js'></script>
<script src='js/fullcalendar.min.js'></script>
<script src='js/jquery-ui.min.js'></script>
<script src="js/custom.js"></script>
</body>

</html>